from django.shortcuts import render
from django.http import HttpResponse

def Home(request):
    temp = 31.5
    context = {'temp':temp}
    return render(request, 'monitor/home.html',context)
