from sense_emu import SenseHat
import time

sense = SenseHat()


while True:
    temp = sense.temp
    text = 'Temp: {:.2f} "C'.format(temp)
    print(text)
    blue = (0, 0, 255)
    sense.show_message(text, scroll_speed=0.2, text_colour=blue)
    time.sleep(10)
