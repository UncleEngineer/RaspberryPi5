from django.shortcuts import render
from django.http import HttpResponse
import csv

def Home(request):
    

    # read data from csv
    path = '/home/pi/Desktop/data-test.csv'
    with open(path,newline='') as file:
        fr = csv.reader(file)
        data = list(fr)
        # print(data)
        data.reverse()

    temp = data[0][0]
    context = {'temp':temp,'data':data}
    return render(request, 'monitor/home.html',context)
