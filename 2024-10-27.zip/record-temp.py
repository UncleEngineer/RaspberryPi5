import csv
from datetime import datetime
from sense_emu import SenseHat
import time

sense = SenseHat()

def savedata(data):
    with open('data-test.csv','a',newline='',encoding='utf-8') as file:
        fw = csv.writer(file)
        fw.writerow(data)


while True:
    stamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    temp = sense.get_temperature()
    humid = sense.get_humidity()
    print(temp, humid)
    dt = [round(temp,2),round(humid,2) ,stamp]
    savedata(dt)
    time.sleep(5)