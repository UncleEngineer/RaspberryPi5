import csv

def savedata(data):
    with open('data-test.csv','a',newline='',encoding='utf-8') as file:
        fw = csv.writer(file)
        fw.writerow(data)

dt = [30,60,'2024-10-27 15:15:10']
savedata(dt)