import csv

path = '/home/pi/Desktop/data-test.csv'
with open(path,newline='') as file:
    fr = csv.reader(file)
    data = list(fr)
    # print(data)
    data.reverse()

for d in data:
    print(d)
